package com.infy.ekart.product.exception;

public class EKartProductException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EKartProductException(String message) {
		super(message);
	}

}
